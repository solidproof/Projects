# x/referral Module

This is the third party provided code for referral 
marketing system module. It's uses x/staking hooks for 
stake change related actions and referral structure coins distribution
