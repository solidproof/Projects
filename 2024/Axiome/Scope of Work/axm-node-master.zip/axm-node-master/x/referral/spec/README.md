# referral module specification

## Abstract

This module provide on chain multi level marketing support

## Contents

