# `/x/{modules}`

This directory contains the code for Axiome chain custom modules.
