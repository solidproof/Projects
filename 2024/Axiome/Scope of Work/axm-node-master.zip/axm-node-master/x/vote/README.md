## x/vote Module

This is an implementation of a governance module with an elected 
government and community polls

It includes functionalities for creating votes, counting votes for a particular proposal, and performing actions based on vote results.