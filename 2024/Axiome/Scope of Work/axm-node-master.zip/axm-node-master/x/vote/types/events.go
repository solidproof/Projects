package types

func (EventProposalCreated) XXX_MessageName() string { return "proposal_created" }

func (EventProposalVote) XXX_MessageName() string { return "proposal_vote" }

func (EventvoteFinished) XXX_MessageName() string { return "vote_finished" }
