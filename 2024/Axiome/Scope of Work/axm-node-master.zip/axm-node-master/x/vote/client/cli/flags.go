package cli

const (
	FlagLimit = "limit"
	FlagPage  = "page"

	FlagLimitDefault = int(30)
	FlagPageDefault  = int(1)
)
