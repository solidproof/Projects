package util

const (
	ConfigMainDenom = "uaxm"
)
